package goFish;

public interface Game {
	void startGame();
	boolean isGameOver();
	void playTurn(Player p);
	void endGame();
}
