package goFish;

public interface GoFishGame extends Game{
}
