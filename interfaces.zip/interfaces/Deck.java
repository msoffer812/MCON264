package goFish;
import java.util.List;

public interface Deck {
	Card drawCard();
	void shuffleDeck();
}
