package goFish;

public interface Card {
	//methods
	void Card(String rank, String suit);
	String getRank();
	String getSuit();
	String toString();
}

